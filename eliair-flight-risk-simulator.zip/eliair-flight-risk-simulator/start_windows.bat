@echo off
setlocal
cd /d "%~dp0"

python --version >nul 2>&1
if errorlevel 1 (
  py -3 --version >nul 2>&1
  if errorlevel 1 (
    echo Python is not installed. Please install Python 3 first.
    pause
    exit /b 1
  )
  py -3 start.py
) else (
  python start.py
)

if errorlevel 1 (
  echo.
  echo Something went wrong while starting ELIAIR Flight Risk Simulator.
  pause
)
