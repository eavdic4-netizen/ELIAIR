const conditionConfig = [
  {
    id: "european_aqi",
    label: "European AQI",
    unit: "AQI",
    step: 1,
    fallback: { min: 10, median: 40, max: 120 },
  },
  {
    id: "pm10",
    label: "PM10",
    unit: "ug/m3",
    step: 0.1,
    fallback: { min: 0, median: 18, max: 240 },
  },
  {
    id: "pm2_5",
    label: "PM2.5",
    unit: "ug/m3",
    step: 0.1,
    fallback: { min: 0, median: 15, max: 230 },
  },
  {
    id: "temperature_2m",
    label: "Temperature",
    unit: "deg C",
    step: 0.1,
    fallback: { min: -15, median: 14, max: 38 },
  },
  {
    id: "relative_humidity_2m",
    label: "Relative humidity",
    unit: "%",
    step: 1,
    fallback: { min: 10, median: 70, max: 100 },
  },
  {
    id: "precipitation",
    label: "Precipitation",
    unit: "mm",
    step: 0.1,
    fallback: { min: 0, median: 0, max: 23 },
  },
  {
    id: "snowfall",
    label: "Snowfall",
    unit: "cm",
    step: 0.1,
    fallback: { min: 0, median: 0, max: 5 },
  },
  {
    id: "cloud_cover",
    label: "Cloud cover",
    unit: "%",
    step: 1,
    fallback: { min: 0, median: 70, max: 100 },
  },
  {
    id: "wind_speed_10m",
    label: "Wind speed",
    unit: "km/h",
    step: 0.1,
    fallback: { min: 0, median: 6, max: 35 },
  },
  {
    id: "wind_gusts_10m",
    label: "Wind gusts",
    unit: "km/h",
    step: 0.1,
    fallback: { min: 0, median: 20, max: 95 },
  },
];

const state = {
  metadata: null,
};

const $ = (id) => document.getElementById(id);

function formatNumber(value, digits = 0) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) {
    return "--";
  }
  return Number(value).toLocaleString(undefined, {
    maximumFractionDigits: digits,
  });
}

function formatFeature(value) {
  return String(value)
    .replaceAll("_", " ")
    .replace("origin iata ", "origin ")
    .replace("origin city ", "city ")
    .replace("airline ", "airline ")
    .replace("relative humidity 2m", "humidity")
    .replace("temperature 2m", "temperature")
    .replace("wind speed 10m", "wind speed")
    .replace("wind gusts 10m", "wind gusts");
}

function toDateTimeLocal(date) {
  const pad = (num) => String(num).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function clearNode(node) {
  while (node.firstChild) {
    node.removeChild(node.firstChild);
  }
}

function makeStat(label, value) {
  const wrap = document.createElement("div");
  const strong = document.createElement("strong");
  const span = document.createElement("span");
  strong.textContent = value;
  span.textContent = label;
  wrap.append(strong, span);
  return wrap;
}

function renderTopStats(metadata) {
  const container = $("topStats");
  clearNode(container);
  const stats = metadata.stats;
  [
    `${formatNumber(stats.rows)} historical arrivals`,
    `${formatNumber(stats.disrupted)} disrupted`,
    `${stats.disruption_rate}% baseline disruption`,
    `ROC AUC ${metadata.metrics.roc_auc_landed}`,
  ].forEach((text) => {
    const chip = document.createElement("span");
    chip.textContent = text;
    container.appendChild(chip);
  });
}

function populateAirlines(metadata) {
  const airline = $("airline");
  clearNode(airline);
  metadata.airlines.forEach((name) => {
    const option = document.createElement("option");
    option.value = name;
    option.textContent = name;
    airline.appendChild(option);
  });
  if (metadata.airlines.includes("Turkish Airlines")) {
    airline.value = "Turkish Airlines";
  }
}

function populateRoutes(metadata) {
  const routeSelect = $("route");
  clearNode(routeSelect);
  metadata.routes.forEach((route) => {
    const option = document.createElement("option");
    option.dataset.iata = route.origin_iata;
    option.dataset.city = route.origin_city;
    option.value = `${route.origin_iata}-${route.origin_city}`;
    option.textContent = `${route.origin_city} (${route.origin_iata})`;
    routeSelect.appendChild(option);
  });
  setRouteByIata("IST");
}

function setRouteByIata(iata) {
  const routeSelect = $("route");
  const match = Array.from(routeSelect.options).find(
    (option) => option.dataset.iata === iata
  );
  if (match) {
    routeSelect.value = match.value;
  }
}

function setAirline(name) {
  const airline = $("airline");
  if (Array.from(airline.options).some((option) => option.value === name)) {
    airline.value = name;
  }
}

function renderConditionSliders(metadata) {
  const container = $("conditionFields");
  clearNode(container);

  conditionConfig.forEach((config) => {
    const range = metadata.numeric_ranges[config.id] || config.fallback;
    const min = Math.floor(range.min);
    const max = Math.ceil(range.max);
    const value = range.median ?? config.fallback.median;

    const field = document.createElement("label");
    field.className = "slider-field";
    field.htmlFor = config.id;

    const top = document.createElement("div");
    top.className = "slider-field__top";

    const label = document.createElement("span");
    label.className = "slider-field__label";
    label.textContent = config.label;

    const output = document.createElement("output");
    output.id = `${config.id}_value`;
    output.textContent = `${formatNumber(value, 1)} ${config.unit}`;

    const input = document.createElement("input");
    input.type = "range";
    input.id = config.id;
    input.name = config.id;
    input.min = min;
    input.max = max;
    input.step = config.step;
    input.value = value;
    input.addEventListener("input", () => {
      output.textContent = `${formatNumber(input.value, 1)} ${config.unit}`;
    });

    const bounds = document.createElement("div");
    bounds.className = "slider-field__bounds";
    const low = document.createElement("span");
    const high = document.createElement("span");
    low.textContent = `${min}`;
    high.textContent = `${max}`;
    bounds.append(low, high);

    top.append(label, output);
    field.append(top, input, bounds);
    container.appendChild(field);
  });
}

function setConditionValues(values) {
  conditionConfig.forEach((config) => {
    if (Object.hasOwn(values, config.id)) {
      const input = $(config.id);
      const output = $(`${config.id}_value`);
      input.value = values[config.id];
      output.textContent = `${formatNumber(values[config.id], 1)} ${config.unit}`;
    }
  });
}

function setDefaultDate() {
  const date = new Date();
  date.setMinutes(0, 0, 0);
  $("arrival_datetime").value = toDateTimeLocal(date);
}

function renderStats(metadata) {
  const grid = $("statGrid");
  clearNode(grid);
  grid.append(
    makeStat("Arrivals", formatNumber(metadata.stats.rows)),
    makeStat("Landed", formatNumber(metadata.stats.landed)),
    makeStat("Cancelled/diverted", formatNumber(metadata.stats.disrupted)),
    makeStat("Date range", `${metadata.stats.date_min} to ${metadata.stats.date_max}`)
  );
}

function renderMonthChart(metadata) {
  const chart = $("monthChart");
  clearNode(chart);
  const maxRate = Math.max(...metadata.month_rates.map((row) => row.disruption_rate), 1);
  metadata.month_rates.forEach((row) => {
    const item = document.createElement("div");
    item.className = "bar-row";
    const label = document.createElement("span");
    const track = document.createElement("div");
    const fill = document.createElement("div");
    const value = document.createElement("span");
    label.textContent = row.month;
    track.className = "bar-track";
    fill.className = "bar-fill";
    fill.style.width = `${Math.max((row.disruption_rate / maxRate) * 100, 2)}%`;
    value.textContent = `${row.disruption_rate}%`;
    track.appendChild(fill);
    item.append(label, track, value);
    chart.appendChild(item);
  });
}

function renderRoutes(metadata) {
  const list = $("routeList");
  clearNode(list);
  metadata.top_disrupted_routes.slice(0, 9).forEach((route) => {
    const item = document.createElement("div");
    item.className = "route-item";
    const left = document.createElement("div");
    const strong = document.createElement("strong");
    const span = document.createElement("span");
    const right = document.createElement("strong");
    strong.textContent = `${route.origin_city} (${route.origin_iata})`;
    span.textContent = route.airline;
    right.textContent = `${route.disruptions}`;
    left.append(strong, span);
    item.append(left, right);
    list.appendChild(item);
  });
}

function payloadFromForm() {
  const selectedRoute = $("route").selectedOptions[0];
  const payload = {
    airline: $("airline").value,
    origin_city: selectedRoute.dataset.city,
    origin_iata: selectedRoute.dataset.iata,
    arrival_datetime: $("arrival_datetime").value,
    weather_code: Number($("weather_code").value),
  };
  conditionConfig.forEach((config) => {
    payload[config.id] = Number($(config.id).value);
  });
  return payload;
}

function setLoading(isLoading) {
  $("predictionForm").classList.toggle("loading", isLoading);
  const button = document.querySelector(".primary-button");
  button.disabled = isLoading;
  button.textContent = isLoading ? "Predicting..." : "Predict disruption risk";
}

function renderPrediction(result) {
  $("resultTitle").textContent = result.prediction;

  const level = $("resultLevel");
  level.textContent = result.level.label;
  level.className = `status-pill ${result.level.tone}`;

  const score = Math.max(0, Math.min(100, Number(result.risk_score)));
  $("riskGauge").style.setProperty("--score", score);
  $("riskScore").textContent = formatNumber(score, 1);
  $("resultSummary").textContent = result.level.summary;
  $("modelScore").textContent = `${formatNumber(result.model_disruption_score, 1)} / 100`;
  $("landedScore").textContent = `${formatNumber(result.landed_score, 1)} / 100`;
  $("smogRisk").textContent = result.computed_features.smog_risk ? "Yes" : "No";
  $("disclaimer").textContent = result.disclaimer;

  const factorList = $("factorList");
  clearNode(factorList);
  result.risk_factors.forEach((factor) => {
    const chip = document.createElement("span");
    chip.className = `factor ${factor.tone}`;
    chip.textContent = `${factor.label}: ${factor.detail}`;
    factorList.appendChild(chip);
  });

  const similar = result.similar_flights;
  $("similarFlights").textContent =
    `${similar.disrupted} of ${similar.count} nearest historical scenarios were cancelled or diverted ` +
    `(${similar.disruption_rate}%).`;

  const route = result.route_context;
  if (route.count > 0) {
    $("routeHistory").textContent =
      `${route.count} matching route records, ${route.disruption_rate}% disrupted ` +
      `versus ${route.overall_disruption_rate}% overall.`;
  } else {
    $("routeHistory").textContent =
      `No direct route history found. Overall disruption rate is ${route.overall_disruption_rate}%.`;
  }
}

async function submitPrediction(event) {
  event.preventDefault();
  setLoading(true);
  try {
    const response = await fetch("/api/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payloadFromForm()),
    });
    if (!response.ok) {
      throw new Error(`Prediction failed with status ${response.status}`);
    }
    renderPrediction(await response.json());
  } catch (error) {
    $("resultTitle").textContent = "Prediction failed";
    $("resultSummary").textContent = error.message;
  } finally {
    setLoading(false);
  }
}

function resetDefaults() {
  setDefaultDate();
  setAirline("Turkish Airlines");
  setRouteByIata("IST");
  $("weather_code").value = "3";
  renderConditionSliders(state.metadata);
}

async function init() {
  const response = await fetch("/api/metadata");
  state.metadata = await response.json();

  renderTopStats(state.metadata);
  populateAirlines(state.metadata);
  populateRoutes(state.metadata);
  renderConditionSliders(state.metadata);
  setDefaultDate();
  renderStats(state.metadata);
  renderMonthChart(state.metadata);
  renderRoutes(state.metadata);

  $("predictionForm").addEventListener("submit", submitPrediction);
  $("resetButton").addEventListener("click", resetDefaults);
}

init().catch((error) => {
  $("topStats").textContent = `Could not load model metadata: ${error.message}`;
});
