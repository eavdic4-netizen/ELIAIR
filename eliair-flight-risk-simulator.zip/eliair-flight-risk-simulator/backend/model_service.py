from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    classification_report,
    confusion_matrix,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.utils.class_weight import compute_sample_weight


APP_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = APP_ROOT / "data"
MODEL_DIR = APP_ROOT / "models"
MODEL_PATH = MODEL_DIR / "landing_risk_pipeline_sklearn.joblib"
METADATA_PATH = MODEL_DIR / "metadata.json"

RANDOM_STATE = 42
LABEL_COLUMN = "able_to_land"

IDENTIFIER_COLUMNS = [
    LABEL_COLUMN,
    "status",
    "flight_number",
    "callsign",
    "scheduled_arrival_datetime",
    "scheduled_hour",
    "aqi_datetime",
]

NUMERIC_DISTANCE_COLUMNS = [
    "arrival_hour",
    "day_of_week",
    "month",
    "is_winter_month",
    "european_aqi",
    "pm10",
    "pm2_5",
    "temperature_2m",
    "relative_humidity_2m",
    "precipitation",
    "snowfall",
    "cloud_cover",
    "wind_speed_10m",
    "wind_gusts_10m",
    "weather_code",
    "smog_risk",
]


def _read_flight_data() -> pd.DataFrame:
    path = DATA_DIR / "flight_environment_dataset.csv"
    df = pd.read_csv(path)
    df["scheduled_arrival_datetime"] = pd.to_datetime(
        df["scheduled_arrival_datetime"], errors="coerce"
    )
    return df.dropna(subset=["scheduled_arrival_datetime"]).reset_index(drop=True)


def _build_feature_frame(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    X = df.drop(columns=[c for c in IDENTIFIER_COLUMNS if c in df.columns], errors="ignore")
    y = df[LABEL_COLUMN].astype(int)
    return X, y


def _make_pipeline(X: pd.DataFrame) -> Pipeline:
    numeric_features = X.select_dtypes(include=["number", "bool"]).columns.tolist()
    categorical_features = X.select_dtypes(exclude=["number", "bool"]).columns.tolist()

    try:
        one_hot_encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError:
        one_hot_encoder = OneHotEncoder(handle_unknown="ignore", sparse=False)

    preprocess = ColumnTransformer(
        transformers=[
            ("num", "passthrough", numeric_features),
            ("cat", one_hot_encoder, categorical_features),
        ],
        remainder="drop",
    )

    model = HistGradientBoostingClassifier(
        loss="log_loss",
        max_iter=220,
        max_leaf_nodes=31,
        learning_rate=0.05,
        l2_regularization=0.01,
        random_state=RANDOM_STATE,
    )

    return Pipeline(
        steps=[
            ("preprocess", preprocess),
            ("model", model),
        ]
    )


def _compute_smog_risk(record: dict[str, Any]) -> int:
    pollution_score = int(record["european_aqi"] >= 65)
    pollution_score += int(record["pm2_5"] >= 25)
    pollution_score += int(record["pm10"] >= 40)

    stagnant_air = (
        record["relative_humidity_2m"] >= 75 and record["wind_speed_10m"] <= 7
    )
    very_polluted_humid_air = (
        (record["european_aqi"] >= 75 or record["pm2_5"] >= 50)
        and record["relative_humidity_2m"] >= 80
        and record["wind_speed_10m"] <= 8
    )
    return int((pollution_score >= 2 and stagnant_air) or very_polluted_humid_air)


def _safe_float(value: Any, fallback: float = 0.0) -> float:
    try:
        if value is None or value == "":
            return fallback
        return float(value)
    except (TypeError, ValueError):
        return fallback


def _risk_level(score: float) -> dict[str, str]:
    if score >= 70:
        return {
            "label": "High",
            "tone": "danger",
            "summary": "Conditions resemble the riskiest historical arrivals in the dataset.",
        }
    if score >= 45:
        return {
            "label": "Elevated",
            "tone": "warning",
            "summary": "Several conditions point toward a higher-than-usual disruption risk.",
        }
    if score >= 22:
        return {
            "label": "Guarded",
            "tone": "notice",
            "summary": "The flight is likely to land, but the scenario deserves attention.",
        }
    return {
        "label": "Low",
        "tone": "good",
        "summary": "The scenario looks similar to mostly successful historical arrivals.",
    }


def _serialize_month_rates(df: pd.DataFrame) -> list[dict[str, Any]]:
    month_names = {
        1: "Jan",
        2: "Feb",
        3: "Mar",
        4: "Apr",
        5: "May",
        6: "Jun",
        7: "Jul",
        8: "Aug",
        9: "Sep",
        10: "Oct",
        11: "Nov",
        12: "Dec",
    }
    rates = (
        df.groupby("month")[LABEL_COLUMN]
        .agg(total="count", landed="sum")
        .reset_index()
        .sort_values("month")
    )
    rates["disruption_rate"] = (1 - rates["landed"] / rates["total"]) * 100
    return [
        {
            "month": month_names[int(row.month)],
            "total": int(row.total),
            "disruption_rate": round(float(row.disruption_rate), 2),
        }
        for row in rates.itertuples()
    ]


def _feature_importance(pipeline: Pipeline) -> list[dict[str, Any]]:
    try:
        feature_names = pipeline.named_steps["preprocess"].get_feature_names_out()
        booster = pipeline.named_steps["model"].get_booster()
        rows = []
        for encoded_name, gain in booster.get_score(importance_type="gain").items():
            feature_index = int(encoded_name[1:])
            rows.append(
                {
                    "feature": str(feature_names[feature_index]).replace("num__", "").replace("cat__", ""),
                    "gain": float(gain),
                }
            )
        rows.sort(key=lambda row: row["gain"], reverse=True)
        return rows[:12]
    except Exception:
        return []


def train_and_save_model() -> dict[str, Any]:
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    df = _read_flight_data()
    X, y = _build_feature_frame(df)

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=RANDOM_STATE,
        stratify=y,
    )

    pipeline = _make_pipeline(X)
    sample_weights = compute_sample_weight(class_weight="balanced", y=y_train)
    pipeline.fit(X_train, y_train, model__sample_weight=sample_weights)

    y_pred = pipeline.predict(X_test)
    proba_landed = pipeline.predict_proba(X_test)[:, 1]
    unsafe_scores = 1 - proba_landed
    y_unsafe = (y_test == 0).astype(int)

    cm = confusion_matrix(y_test, y_pred, labels=[0, 1])
    metrics = {
        "accuracy": round(float(accuracy_score(y_test, y_pred)), 4),
        "roc_auc_landed": round(float(roc_auc_score(y_test, proba_landed)), 4),
        "average_precision_unsafe": round(
            float(average_precision_score(y_unsafe, unsafe_scores)), 4
        ),
        "confusion_matrix": cm.tolist(),
        "classification_report": classification_report(
            y_test,
            y_pred,
            labels=[0, 1],
            target_names=["Did not land", "Landed"],
            zero_division=0,
            output_dict=True,
        ),
    }

    model_scores_full = 1 - pipeline.predict_proba(X)[:, 1]
    artifact = {
        "pipeline": pipeline,
        "feature_columns": X.columns.tolist(),
        "numeric_features": X.select_dtypes(include=["number", "bool"]).columns.tolist(),
        "categorical_features": X.select_dtypes(exclude=["number", "bool"]).columns.tolist(),
        "metrics": metrics,
        "score_quantiles": np.quantile(
            model_scores_full, [0.25, 0.5, 0.75, 0.9, 0.95]
        ).round(4).tolist(),
    }
    joblib.dump(artifact, MODEL_PATH)

    metadata = build_metadata(df, artifact)
    METADATA_PATH.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return artifact


def load_or_train_model() -> dict[str, Any]:
    if MODEL_PATH.exists() and METADATA_PATH.exists():
        return joblib.load(MODEL_PATH)
    return train_and_save_model()


def build_metadata(df: pd.DataFrame, artifact: dict[str, Any]) -> dict[str, Any]:
    overall_total = len(df)
    overall_nonlanded = int((df[LABEL_COLUMN] == 0).sum())

    route_counts = (
        df.groupby(["origin_iata", "origin_city"])
        .size()
        .reset_index(name="count")
        .sort_values(["count", "origin_city"], ascending=[False, True])
    )
    routes = [
        {
            "origin_iata": str(row.origin_iata),
            "origin_city": str(row.origin_city),
            "count": int(row.count),
        }
        for row in route_counts.itertuples()
    ]

    numeric_ranges = {}
    for col in NUMERIC_DISTANCE_COLUMNS:
        if col in df.columns:
            numeric_ranges[col] = {
                "min": round(float(df[col].min()), 2),
                "median": round(float(df[col].median()), 2),
                "max": round(float(df[col].max()), 2),
            }

    top_airlines = df["airline"].value_counts().head(20)
    top_routes = (
        df[df[LABEL_COLUMN] == 0]
        .groupby(["airline", "origin_city", "origin_iata"])
        .size()
        .reset_index(name="disruptions")
        .sort_values("disruptions", ascending=False)
        .head(12)
    )

    return {
        "stats": {
            "rows": int(overall_total),
            "landed": int(df[LABEL_COLUMN].sum()),
            "disrupted": overall_nonlanded,
            "disruption_rate": round(overall_nonlanded / overall_total * 100, 2),
            "date_min": str(df["scheduled_arrival_datetime"].min().date()),
            "date_max": str(df["scheduled_arrival_datetime"].max().date()),
        },
        "airlines": sorted(str(a) for a in df["airline"].dropna().unique()),
        "routes": routes,
        "top_airlines": [
            {"airline": str(airline), "count": int(count)}
            for airline, count in top_airlines.items()
        ],
        "top_disrupted_routes": [
            {
                "airline": str(row.airline),
                "origin_city": str(row.origin_city),
                "origin_iata": str(row.origin_iata),
                "disruptions": int(row.disruptions),
            }
            for row in top_routes.itertuples()
        ],
        "month_rates": _serialize_month_rates(df),
        "numeric_ranges": numeric_ranges,
        "feature_importance": _feature_importance(artifact["pipeline"]),
        "metrics": artifact["metrics"],
        "score_quantiles": artifact["score_quantiles"],
    }


@dataclass
class PredictionResult:
    row: pd.DataFrame
    record: dict[str, Any]


class ModelService:
    def __init__(self) -> None:
        self.df = _read_flight_data()
        self.artifact = load_or_train_model()
        if METADATA_PATH.exists():
            self.metadata = json.loads(METADATA_PATH.read_text(encoding="utf-8"))
        else:
            self.metadata = build_metadata(self.df, self.artifact)
        self._distance_stats = self._build_distance_stats()

    def _build_distance_stats(self) -> dict[str, pd.Series]:
        existing_cols = [c for c in NUMERIC_DISTANCE_COLUMNS if c in self.df.columns]
        means = self.df[existing_cols].mean(numeric_only=True)
        stds = self.df[existing_cols].std(numeric_only=True).replace(0, 1)
        return {"columns": existing_cols, "means": means, "stds": stds}

    def metadata_response(self) -> dict[str, Any]:
        return self.metadata

    def _record_from_payload(self, payload: dict[str, Any]) -> PredictionResult:
        raw_dt = str(payload.get("arrival_datetime") or "").strip()
        try:
            arrival_dt = datetime.fromisoformat(raw_dt)
        except ValueError:
            arrival_dt = datetime.now().replace(minute=0, second=0, microsecond=0)

        record = {
            "airline": str(payload.get("airline") or "Turkish Airlines"),
            "origin_city": str(payload.get("origin_city") or "Istanbul"),
            "origin_iata": str(payload.get("origin_iata") or "IST").upper(),
            "arrival_hour": int(arrival_dt.hour),
            "day_of_week": int(arrival_dt.weekday()),
            "month": int(arrival_dt.month),
            "is_winter_month": int(arrival_dt.month in [11, 12, 1, 2]),
            "european_aqi": _safe_float(payload.get("european_aqi"), 40),
            "pm10": _safe_float(payload.get("pm10"), 18),
            "pm2_5": _safe_float(payload.get("pm2_5"), 15),
            "temperature_2m": _safe_float(payload.get("temperature_2m"), 14),
            "relative_humidity_2m": _safe_float(payload.get("relative_humidity_2m"), 70),
            "precipitation": _safe_float(payload.get("precipitation"), 0),
            "snowfall": _safe_float(payload.get("snowfall"), 0),
            "cloud_cover": _safe_float(payload.get("cloud_cover"), 70),
            "wind_speed_10m": _safe_float(payload.get("wind_speed_10m"), 6),
            "wind_gusts_10m": _safe_float(payload.get("wind_gusts_10m"), 20),
            "weather_code": int(_safe_float(payload.get("weather_code"), 3)),
        }
        record["smog_risk"] = _compute_smog_risk(record)

        feature_columns = self.artifact["feature_columns"]
        row = pd.DataFrame([{column: record.get(column, 0) for column in feature_columns}])
        return PredictionResult(row=row, record=record)

    def _similar_flights(self, record: dict[str, Any]) -> dict[str, Any]:
        cols = self._distance_stats["columns"]
        means = self._distance_stats["means"]
        stds = self._distance_stats["stds"]

        sample = pd.Series({col: record.get(col, means[col]) for col in cols})
        numeric_distance = (((self.df[cols] - sample) / stds) ** 2).sum(axis=1)

        category_penalty = pd.Series(np.zeros(len(self.df)), index=self.df.index)
        category_penalty += (self.df["airline"] != record["airline"]).astype(float) * 0.75
        category_penalty += (self.df["origin_iata"] != record["origin_iata"]).astype(float) * 0.55

        distances = numeric_distance + category_penalty
        neighbor_count = min(250, len(self.df))
        neighbors = self.df.loc[distances.nsmallest(neighbor_count).index]
        disrupted = int((neighbors[LABEL_COLUMN] == 0).sum())
        total = int(len(neighbors))

        return {
            "count": total,
            "disrupted": disrupted,
            "landed": int(neighbors[LABEL_COLUMN].sum()),
            "disruption_rate": round(disrupted / total * 100, 2) if total else 0,
            "top_statuses": [
                {"status": str(status), "count": int(count)}
                for status, count in neighbors["status"].value_counts().items()
            ],
        }

    def _route_context(self, record: dict[str, Any]) -> dict[str, Any]:
        overall = (self.df[LABEL_COLUMN] == 0).mean() * 100

        route = self.df[
            (self.df["airline"] == record["airline"])
            & (self.df["origin_iata"] == record["origin_iata"])
        ]
        if len(route) < 20:
            route = self.df[self.df["origin_iata"] == record["origin_iata"]]

        if len(route) == 0:
            return {
                "count": 0,
                "disruption_rate": None,
                "overall_disruption_rate": round(float(overall), 2),
            }

        route_rate = (route[LABEL_COLUMN] == 0).mean() * 100
        return {
            "count": int(len(route)),
            "disruption_rate": round(float(route_rate), 2),
            "overall_disruption_rate": round(float(overall), 2),
        }

    def _risk_factors(self, record: dict[str, Any], route_context: dict[str, Any]) -> list[dict[str, str]]:
        factors: list[dict[str, str]] = []

        if record["is_winter_month"]:
            factors.append(
                {
                    "label": "Winter arrival",
                    "detail": "Winter months had the highest historical disruption rates.",
                    "tone": "warning",
                }
            )
        if record["smog_risk"]:
            factors.append(
                {
                    "label": "Smog-risk pattern",
                    "detail": "Pollution plus humid, slow-moving air matches the project smog-risk rule.",
                    "tone": "warning",
                }
            )
        if record["relative_humidity_2m"] >= 85:
            factors.append(
                {
                    "label": "Very humid air",
                    "detail": "High humidity can coincide with fog or poor visibility in Sarajevo's valley setting.",
                    "tone": "notice",
                }
            )
        if record["wind_gusts_10m"] >= 45:
            factors.append(
                {
                    "label": "Strong gusts",
                    "detail": "Gusty conditions can make approaches less stable.",
                    "tone": "warning",
                }
            )
        if record["snowfall"] > 0:
            factors.append(
                {
                    "label": "Snowfall",
                    "detail": "Snow adds operational complexity for arrivals and runway handling.",
                    "tone": "warning",
                }
            )
        if record["european_aqi"] >= 75 or record["pm2_5"] >= 50:
            factors.append(
                {
                    "label": "High pollution load",
                    "detail": "AQI or PM2.5 is high compared with typical values in the dataset.",
                    "tone": "notice",
                }
            )
        if route_context.get("disruption_rate") is not None:
            route_rate = float(route_context["disruption_rate"])
            overall = float(route_context["overall_disruption_rate"])
            if route_rate >= overall * 1.5 and route_context["count"] >= 20:
                factors.append(
                    {
                        "label": "Route pattern",
                        "detail": f"This route/airline history is {route_rate:.2f}% disrupted versus {overall:.2f}% overall.",
                        "tone": "notice",
                    }
                )

        if not factors:
            factors.append(
                {
                    "label": "No major red flags",
                    "detail": "The entered conditions do not trigger the main environmental risk rules.",
                    "tone": "good",
                }
            )
        return factors[:5]

    def predict(self, payload: dict[str, Any]) -> dict[str, Any]:
        prepared = self._record_from_payload(payload)
        proba_landed = float(self.artifact["pipeline"].predict_proba(prepared.row)[0, 1])
        raw_disruption_score = (1 - proba_landed) * 100

        quantiles = self.artifact.get("score_quantiles", [0.1, 0.2, 0.4, 0.65, 0.8])
        raw_fraction = raw_disruption_score / 100
        calibrated_score = float(np.interp(raw_fraction, quantiles, [25, 50, 75, 90, 95]))
        score = round((raw_disruption_score * 0.65) + (calibrated_score * 0.35), 1)

        route_context = self._route_context(prepared.record)
        similar = self._similar_flights(prepared.record)
        level = _risk_level(score)

        return {
            "risk_score": score,
            "model_disruption_score": round(raw_disruption_score, 1),
            "landed_score": round(proba_landed * 100, 1),
            "level": level,
            "prediction": "Possible disruption" if score >= 45 else "Likely to land",
            "computed_features": prepared.record,
            "risk_factors": self._risk_factors(prepared.record, route_context),
            "route_context": route_context,
            "similar_flights": similar,
            "disclaimer": (
                "This is a project model trained on historical Sarajevo arrivals. It estimates "
                "environmental landing/disruption risk, not the official operational status of a flight."
            ),
        }
