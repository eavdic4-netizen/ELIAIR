from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

try:
    from .model_service import ModelService
except ImportError:
    from model_service import ModelService


APP_ROOT = Path(__file__).resolve().parents[1]
FRONTEND_DIR = APP_ROOT / "frontend"
STATIC_DIR = APP_ROOT / "static"
APP_PATH = "/eliair-flight-risk-simulator"


class PredictionRequest(BaseModel):
    airline: str
    origin_city: str
    origin_iata: str
    arrival_datetime: str
    european_aqi: float
    pm10: float
    pm2_5: float
    temperature_2m: float
    relative_humidity_2m: float
    precipitation: float
    snowfall: float
    cloud_cover: float
    wind_speed_10m: float
    wind_gusts_10m: float
    weather_code: int


app = FastAPI(
    title="ELIAIR Flight Risk Simulator",
    description="Interactive landing disruption risk demo for Sarajevo arrivals.",
)
service = ModelService()

app.mount("/frontend", StaticFiles(directory=FRONTEND_DIR), name="frontend")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
def root() -> RedirectResponse:
    return RedirectResponse(url=APP_PATH)


@app.get(APP_PATH)
@app.get(f"{APP_PATH}/")
def index() -> FileResponse:
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/metadata")
def metadata() -> dict[str, Any]:
    return service.metadata_response()


@app.post("/api/predict")
def predict(payload: PredictionRequest) -> dict[str, Any]:
    return service.predict(payload.model_dump())
