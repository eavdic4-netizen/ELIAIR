#!/usr/bin/env bash
cd "$(dirname "$0")"

if command -v python3 >/dev/null 2>&1; then
  PYTHON="python3"
elif command -v python >/dev/null 2>&1; then
  PYTHON="python"
else
  echo "Python is not installed. Please install Python 3 first."
  echo
  read -n 1 -s -r -p "Press any key to close this window."
  exit 1
fi

"$PYTHON" start.py

echo
read -n 1 -s -r -p "Press any key to close this window."
