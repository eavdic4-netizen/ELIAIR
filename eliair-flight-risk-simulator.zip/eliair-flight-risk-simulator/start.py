from __future__ import annotations

import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path


HOST = "127.0.0.1"
APP_PATH = "/eliair-flight-risk-simulator"
VENV_DIR = ".venv"


def venv_python(project_dir: Path) -> Path:
    if sys.platform.startswith("win"):
        return project_dir / VENV_DIR / "Scripts" / "python.exe"
    return project_dir / VENV_DIR / "bin" / "python"


def find_available_port(start: int = 8000, limit: int = 30) -> int:
    for port in range(start, start + limit):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.2)
            if sock.connect_ex((HOST, port)) != 0:
                return port
    raise RuntimeError("Could not find an available local port.")


def website_url(port: int) -> str:
    return f"http://{HOST}:{port}{APP_PATH}"


def wait_for_website(port: int, timeout: int = 60) -> bool:
    deadline = time.time() + timeout
    url = website_url(port)
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=2) as response:
                return response.status == 200
        except Exception:
            time.sleep(1)
    return False


def open_browser_when_ready(port: int) -> None:
    if wait_for_website(port):
        webbrowser.open(website_url(port))
    else:
        print()
        print("The browser did not open because the website was not ready yet.")
        print(f"Try opening this URL manually: {website_url(port)}")


def ensure_virtual_environment(project_dir: Path) -> Path:
    python_path = venv_python(project_dir)
    if python_path.exists():
        return python_path

    print("Creating local Python environment...")
    subprocess.check_call([sys.executable, "-m", "venv", VENV_DIR], cwd=project_dir)
    return python_path


def run() -> int:
    project_dir = Path(__file__).resolve().parent
    port = find_available_port()
    python_path = ensure_virtual_environment(project_dir)

    print("Installing required Python packages...")
    subprocess.check_call(
        [str(python_path), "-m", "pip", "install", "-r", "requirements.txt"],
        cwd=project_dir,
    )

    url = website_url(port)
    print()
    print("Starting ELIAIR Flight Risk Simulator...")
    print(f"Website URL: {url}")
    print("The website should open automatically in a few seconds.")
    print("Press Ctrl+C in this terminal to stop the server.")
    print()

    threading.Thread(target=open_browser_when_ready, args=(port,), daemon=True).start()
    return subprocess.call(
        [
            str(python_path),
            "-m",
            "uvicorn",
            "backend.app:app",
            "--host",
            HOST,
            "--port",
            str(port),
        ],
        cwd=project_dir,
    )


if __name__ == "__main__":
    try:
        raise SystemExit(run())
    except KeyboardInterrupt:
        print("\nServer stopped.")
