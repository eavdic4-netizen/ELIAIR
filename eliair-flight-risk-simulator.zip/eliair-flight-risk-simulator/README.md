# ELIAIR Flight Risk Simulator

This folder contains the ELIAIR website demo. It runs locally on your own
computer, then opens in your browser.

The website estimates Sarajevo flight landing/disruption risk from flight
details, weather, and air-quality conditions.

## Quick Start

1. Unzip `eliair-flight-risk-simulator.zip`.
2. Open the unzipped `eliair-flight-risk-simulator` folder.
3. Start the app using the instructions for your operating system below.
4. Keep the Terminal/command window open while using the website.

The website will open automatically if everything works.

If it does not open automatically, copy the URL printed in the Terminal/command
window. It will look similar to this:

```text
http://127.0.0.1:8000/eliair-flight-risk-simulator
```

The port may be `8001`, `8002`, or another number if `8000` is already busy.
Always use the exact URL printed by the launcher.

## Before You Start

You need:

- Python 3 installed
- Internet connection on the first run
- The whole project folder, not just one file

The first run can take a few minutes because Python installs the required
packages and creates a local `.venv` folder. That is normal.

## Windows

1. Open the `eliair-flight-risk-simulator` folder.
2. Double-click `start_windows.bat`.
3. Wait while packages install.
4. The browser should open automatically.

If the browser does not open, copy the URL from the black command window and
paste it into your browser.

## macOS

Recommended method:

1. Open Terminal.
2. Type `cd ` with a space after it.
3. Drag the `eliair-flight-risk-simulator` folder into Terminal.
4. Press Enter.
5. Run this command:

```bash
python3 start.py
```

Example:

```bash
cd /Users/yourname/Downloads/eliair-flight-risk-simulator
python3 start.py
```

Important: do not type the folder path by itself. Use `cd` first.

If you try to double-click `start_mac_linux.sh`, macOS may open it in VS Code or
TextEdit. That does not run the website. Use Terminal instead.

Optional macOS launcher:

```bash
chmod +x start_mac.command
./start_mac.command
```

## Linux

Open Terminal in the `eliair-flight-risk-simulator` folder and run:

```bash
python3 start.py
```

If `python3` is not available, try:

```bash
python start.py
```

## How To Know It Worked

The Terminal/command window should show something like:

```text
Starting ELIAIR Flight Risk Simulator...
Website URL: http://127.0.0.1:8000/eliair-flight-risk-simulator
Press Ctrl+C in this terminal to stop the server.
```

Then the website should open in your browser.

Do not close the Terminal/command window while using the website. Closing it
stops the local server.

## If The Browser Says It Cannot Connect

Check these things:

1. Make sure the Terminal/command window is still open.
2. Copy the exact URL printed in Terminal and paste it into the browser.
3. Wait a few more seconds after the packages finish installing.
4. If there is an error in Terminal, read the last lines first.

Most connection problems happen because the server stopped, the browser opened
too early, or the wrong port was used.

## How To Stop The Website

Go back to the Terminal/command window and press:

```text
Ctrl+C
```

## What The App Predicts

The app estimates whether a flight scenario resembles historical Sarajevo
arrivals that landed, diverted, or were cancelled.

It should be presented as an environmental landing/disruption risk simulator,
not as an official flight-status checker or guaranteed cancellation predictor.

## Project Notes

The research notebooks use XGBoost for landing-risk classification. This shared
website package uses a compatible scikit-learn gradient-boosting classifier so
it can run on Windows, macOS, and Linux without extra system libraries.

The LSTM AQI forecasting module is part of the wider ELIAIR project, but live
LSTM inference is not included in this website because the saved LSTM checkpoint
was not included in the original project archive.

## Folder Contents

- `start.py`: cross-platform launcher
- `start_windows.bat`: Windows launcher
- `start_mac.command`: optional macOS launcher
- `start_mac_linux.sh`: optional macOS/Linux shell launcher
- `backend/`: local API and prediction model code
- `frontend/`: website interface
- `data/`: processed ELIAIR datasets
- `models/`: generated model metadata and local model after first run
- `static/`: images and visual assets
